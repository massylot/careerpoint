$('.background-slider').slick();

// photo gallery//

$('.slider-flex').slick({
    centerMode: true,
    centerPadding: '20px',
    slidesToShow: 4,
    responsive: [
      {
        breakpoint: 768,
        settings: {
          arrows: false,
          centerMode: true,
          centerPadding: '40px',
          slidesToShow: 3
        }
      },
      {
        breakpoint: 480,
        settings: {
          arrows: false,
          centerMode: true,
          centerPadding: '0px',
          slidesToShow: 2
        }
      }
    ]
  });
          

  // tabs///

  const loginPopup = document.querySelector(".login-popup");
const close = document.querySelector(".close");


window.addEventListener("load", function () {

    showPopup();
    // setTimeout(function(){
    //   loginPopup.classList.add("show");
    // },5000)

})

function showPopup() {
    const timeLimit = 2 // seconds;
    let i = 0;
    const timer = setInterval(function () {
        i++;
        if (i == timeLimit) {
            clearInterval(timer);
            loginPopup.classList.add("show");
        }
        console.log(i)
    }, 1000);
}


close.addEventListener("click", function () {
    loginPopup.classList.remove("show");
})


// form//

document.addEventListener('DOMContentLoaded', function () {
  const goToLogin = document.getElementById('goToLogin');
  const goToRegister = document.getElementById('goToRegister');
  const registrationForm = document.getElementById('registrationForm');
  const loginForm = document.getElementById('loginForm');
  const registerForm = document.getElementById('register');
  const loginFormElement = document.getElementById('login');

  let users = [];

  // Switch to Login form
  goToLogin.addEventListener('click', function () {
      registrationForm.style.display = 'none';
      loginForm.style.display = 'block';
  });

  // Switch to Registration form
  goToRegister.addEventListener('click', function () {
      loginForm.style.display = 'none';
      registrationForm.style.display = 'block';
  });

  // Handle Registration
  registerForm.addEventListener('submit', function (e) {
      e.preventDefault();
      
      const name = document.getElementById('name').value;
      const email = document.getElementById('email').value;
      const username = document.getElementById('username').value;
      const password = document.getElementById('password').value;
      const confirmPassword = document.getElementById('confirmPassword').value;

      if (password !== confirmPassword) {
          alert("Passwords do not match!");
          return;
      }

      // Save user details
      const user = {
          name: name,
          email: email,
          username: username,
          password: password
      };

      users.push(user);

      alert("Registration successful! You can now login.");

      registrationForm.style.display = 'none';
      loginForm.style.display = 'block';
  });

  // Handle Login
  loginFormElement.addEventListener('submit', function (e) {
      e.preventDefault();
      
      const loginUsername = document.getElementById('loginUsername').value;
      const loginPassword = document.getElementById('loginPassword').value;

      const user = users.find(user => user.username === loginUsername && user.password === loginPassword);

      if (user) {
          alert("Login successful! Starting exam...");
          // Redirect to exam page or start exam logic here
      } else {
          alert("Invalid username or password.");
      }
  });
});


// slider//

$('.course-flex').slick({
  centerMode: true,
  centerPadding: '20px',
  slidesToShow: 4,
  responsive: [
    {
      breakpoint: 768,
      settings: {
        arrows: false,
        centerMode: true,
        centerPadding: '40px',
        slidesToShow: 3
      }
    },
    {
      breakpoint: 480,
      settings: {
        arrows: false,
        centerMode: true,
        centerPadding: '0px',
        slidesToShow: 2
      }
    }
  ]
});

// demo///

document.getElementById('registrationForm').addEventListener('submit', function(event) {
  event.preventDefault(); // Prevent form from submitting

  // Simple validation
  const form = event.target;
  const fullName = form.fullName.value.trim();
  const email = form.email.value.trim();
  const phone = form.phone.value.trim();
  const dob = form.dob.value;
  const address = form.address.value.trim();
  const state = form.state.value;
  const pincode = form.pincode.value.trim();

  if (fullName === '' || email === '' || phone === '' || dob === '' || address === '' || state === '' || pincode === '') {
      document.getElementById('formMessage').innerText = 'Please fill out all fields.';
      return;
  }

  // Simulate form submission
  document.getElementById('formMessage').innerText = 'Registration Successful!';
  form.reset(); // Reset form fields
});



// card-slider///

$('.card-container').slick({
  slidesToShow: 3,
  slidesToScroll: 1,
  autoplay: true,
  autoplaySpeed: 2000,
});

// popup//
// function showPopup() {
//   document.getElementById('popup-form').classList.add('show');
//   document.getElementById('popup-overlay').classList.add('show');
// }

// function hidePopup() {
//   document.getElementById('popup-form').classList.remove('show');
//   document.getElementById('popup-overlay').classList.remove('show');
// }


function generateChatGPTResponse() {
  const tableRows = document.querySelectorAll('tbody tr');
  let summary = "Here is a summary of your academic details:\n\n";

  tableRows.forEach(row => {
    const className = row.querySelector('td[data-label="Current Class"]').textContent;
    const board = row.querySelector('td[data-label="Board"]').textContent;
    const year = row.querySelector('td[data-label="Year of Passing"]').textContent;
    const subjects = row.querySelector('td[data-label="Subjects"]').textContent;
    const maxMarks = row.querySelector('td[data-label="Max Marks"]').textContent;
    const marksObtained = row.querySelector('td[data-label="Marks Obtained"]').textContent;
    const percentage = row.querySelector('td[data-label="Percentage (%)"]').textContent;

    summary += `- Class: ${className}\n  Board: ${board}\n  Year: ${year}\n  Subjects: ${subjects}\n  Marks: ${marksObtained}/${maxMarks} (${percentage})\n\n`;
  });

  document.getElementById('chatgptResponse').textContent = summary;
  document.getElementById('chatgptResponse').style.display = 'block';
}


// iit to year///
document.getElementById('registrationForm').addEventListener('submit', function(event) {
  event.preventDefault();
  const name = document.getElementById('fullName').value;
  const email = document.getElementById('email').value;
  const phone = document.getElementById('phone').value;
  
  if(name === '' || email === '' || phone === '') {
      alert('Please fill out all required fields.');
  } else {
      alert('Thank you for registering, ' + name + '! We will get in touch with you soon.');
      // Here, you can add further logic to handle form submission, e.g., sending data to a server.
  }
});


// captcha///

function generateCaptcha() {
  const captcha = Math.random().toString(36).substring(2, 8).toUpperCase();
  document.getElementById('captcha').innerText = captcha;
  document.getElementById('captchaMessage').innerText = '';
  document.getElementById('captchaInput').value = '';
}

// Validate CAPTCHA
document.getElementById('registrationForm').addEventListener('submit', function(event) {
  event.preventDefault();
  const enteredCaptcha = document.getElementById('captchaInput').value.toUpperCase();
  const generatedCaptcha = document.getElementById('captcha').innerText;

  if (enteredCaptcha === generatedCaptcha) {
      document.getElementById('captchaMessage').innerText = '';
      document.getElementById('formMessage').innerText = 'Form submitted successfully!';
      // Form submission logic goes here
  } else {
      document.getElementById('captchaMessage').innerText = 'Incorrect CAPTCHA, please try again.';
      document.getElementById('formMessage').innerText = '';
      generateCaptcha(); // Generate new CAPTCHA if the previous one was incorrect
  }
});

// Generate CAPTCHA when the page loads
window.onload = generateCaptcha;


// toggle menu top//
// Open Popup Form
function openPopup() {
  document.getElementById("popupForm").style.display = "block";
}

// Close Popup Form
function closePopup() {
  document.getElementById("popupForm").style.display = "none";
}

// Simulate Sending OTP
function sendOTP() {
  // Show OTP field after clicking Send OTP button
  document.getElementById("otpSection").style.display = "block";
  alert("OTP has been sent to your mobile number.");
}

// Form Submission Event
document.getElementById("registrationForm").addEventListener("submit", function(event) {
  event.preventDefault(); // Prevent default form submission

  // You can handle form submission here, like sending data to a server or validating input
  alert("Form submitted successfully!");
  closePopup(); // Close the popup after successful submission
});